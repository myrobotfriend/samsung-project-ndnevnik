package com.doctorixx.easyDnevnik.exceptions;

public class DnevnikConnectException extends DnevnikException{

    public DnevnikConnectException(){
        super();
    }

    public DnevnikConnectException(String msg){
        super(msg);
    }

}
