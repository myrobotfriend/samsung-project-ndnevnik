package com.doctorixx.dnevnikApp.storage.containers;

public class AppDataContainer {
}
