package com.doctorixx.dnevnikApp.tasks.dataclasses;

public interface OnTaskEndedListener {
    void onEnded();
}
