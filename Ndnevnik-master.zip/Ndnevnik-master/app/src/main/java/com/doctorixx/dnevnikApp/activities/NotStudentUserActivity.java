package com.doctorixx.dnevnikApp.activities;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.doctroixx.NDnevnik.R;

public class NotStudentUserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_not_student_user);
    }
}