package com.doctorixx.dnevnikApp.storage;

public class SharedFileName {

    public static final String appDataFileName = "appData";
    public static final String authFileName = "authData";

}
