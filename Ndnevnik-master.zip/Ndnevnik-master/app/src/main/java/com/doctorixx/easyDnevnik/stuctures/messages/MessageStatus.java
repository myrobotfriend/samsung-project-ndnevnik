package com.doctorixx.easyDnevnik.stuctures.messages;

public enum MessageStatus {
    READ,
    UNREAD,
    ERROR
}
