package com.doctorixx.easyDnevnik.stuctures;

public enum Gender {
    MALE,
    FEMALE
}
