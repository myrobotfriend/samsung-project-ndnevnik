package com.doctorixx.dnevnikApp.tasks.dataclasses;

import com.doctorixx.easyDnevnik.stuctures.ProfileInfo;

public interface OnProfileTaskEnded {
    void onTaskEnded(ProfileInfo profileInfo);
}
