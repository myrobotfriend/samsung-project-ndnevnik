package com.doctorixx.easyDnevnik.exceptions;

public class DnevnikException extends Exception {

    public DnevnikException(){
        super();
    }

    public DnevnikException(String msg){
        super(msg);
    }

}
