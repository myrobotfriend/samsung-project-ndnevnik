package com.doctorixx.easyDnevnik.stuctures;

public enum DayType {
    ORDINARY,
    NOLESSON,
    HOLIDAY,
}
