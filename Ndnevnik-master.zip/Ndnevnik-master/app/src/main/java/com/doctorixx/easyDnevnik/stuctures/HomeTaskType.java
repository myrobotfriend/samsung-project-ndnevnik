package com.doctorixx.easyDnevnik.stuctures;

public enum HomeTaskType {
    TEXT,
    FILE,
}
