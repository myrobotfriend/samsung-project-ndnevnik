package com.doctorixx.easyDnevnik.exceptions;

public class DnevnikAuthException extends DnevnikException{

    public DnevnikAuthException(){
        super();
    }

    public DnevnikAuthException(String msg){
        super(msg);
    }





}
