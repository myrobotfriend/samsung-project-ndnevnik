package com.doctorixx.eljur_analytics;

public abstract class Request {
}
